// Copyright 2023 QMK
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#include "test_common.h"

#define LEADER_KEY_STRICT_KEY_PROCESSING
